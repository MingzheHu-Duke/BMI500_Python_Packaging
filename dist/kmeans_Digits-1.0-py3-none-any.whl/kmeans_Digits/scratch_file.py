import os
direc = "./model_test"

if not os.path.exists(direc):
    os.makedirs(direc)