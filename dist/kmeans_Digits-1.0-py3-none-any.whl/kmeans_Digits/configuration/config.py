import pathlib
import os


DATA_PATH = "./data/sklearn_digits/"
SAVED_MODEL_PATH = "./kmeans_model/"
IMAGE = ["X_train.csv", "X_test.csv"]
LABEL = ["y_train.csv", "y_test.csv"]
CLUSTER_NUM = 10
RANDOM_STATE = 2021

